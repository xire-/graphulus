﻿using UnityEngine;
using System.Collections;

public class World : MonoBehaviour
{
    void Start()
    {
        Reset();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            Reset();
        }
    }


    void Reset()
    {
        foreach (var gameObject in GameObject.FindGameObjectsWithTag("Brick"))
        {
            Destroy(gameObject);
        }

        for (var x = 0; x <= 6; x++)
        {
            for (var y = 0; y <= 4; y++)
            {
                GameObject brick = GameObject.CreatePrimitive(PrimitiveType.Cube);
                brick.transform.localScale = new Vector3(0.1f, 0.05f, 0.05f);
                brick.transform.position = new Vector3(Mathf.Lerp(-0.5f, 0.5f, x / 6f), Mathf.Lerp(0.8f, 1.3f, y / 4f), 0f);
                brick.transform.parent = gameObject.transform;
                brick.tag = "Brick";
                brick.name = string.Format("Brick[{0:d}][{1:d}]", x, y);
            }
        }
    }
}
