﻿using UnityEngine;

public class Paddle : MonoBehaviour
{
    private float speed;

    void Start()
    {
        speed = 1f;
    }

    void Update()
    {
        float direction;
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            direction = -speed * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            direction = speed * Time.deltaTime;
        }
        else
        {
            return;
        }

        float lower = GameObject.Find("LeftBorder").transform.position.x + gameObject.transform.localScale.x / 2;
        float upper = GameObject.Find("RightBorder").transform.position.x - gameObject.transform.localScale.x / 2;
        gameObject.transform.position = new Vector3(
            Utils.Clamp(lower, gameObject.transform.position.x + direction, upper),
            gameObject.transform.position.y,
            gameObject.transform.position.z);
    }
}
