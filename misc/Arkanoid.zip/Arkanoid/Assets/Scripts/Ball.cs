﻿using UnityEngine;

public class Ball : MonoBehaviour
{
    private float speed;
    private Vector3 originalPosition, direction;

    void Start()
    {
        originalPosition = gameObject.transform.position;
        Reset();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            Reset();
        }

        Light light = GameObject.Find("Directional Light").GetComponent<Light>();
        light.color = UnityEditor.EditorGUIUtility.HSVToRGB(Utils.SaneMod(gameObject.transform.position.x + gameObject.transform.position.y, 1), 1, 1);
    }

    void FixedUpdate()
    {
        gameObject.transform.position += Time.fixedDeltaTime * (speed * direction);
    }


    void Reset()
    {
        speed = 0.7f;
        gameObject.transform.position = originalPosition;
        direction = new Vector3(0f, -1f, 0f);
    }


    void OnTriggerEnter(Collider other)
    {
        if (other.name == "Paddle")
        {
            if (direction.y < 0)
            {
                Vector3 closestPoint = other.ClosestPointOnBounds(gameObject.transform.position);
                float angle = (closestPoint.x - other.transform.position.x) / (other.transform.localScale.x / 2);
                direction.x = Mathf.Sin(angle);
                direction.y = Mathf.Cos(angle);
            }
        }
        else if (other.tag == "Brick")
        {
            Vector3 position = gameObject.transform.position;
            bool xColl = position.x < other.gameObject.transform.position.x - other.gameObject.transform.localScale.x / 2
                || position.x > other.gameObject.transform.position.x + other.gameObject.transform.localScale.x / 2;
            bool yColl = position.y < other.gameObject.transform.position.y - other.gameObject.transform.localScale.y / 2
                || position.y > other.gameObject.transform.position.y + other.gameObject.transform.localScale.y / 2;
            if (xColl && yColl)
            {
                Vector3 tmp = other.gameObject.transform.position - other.ClosestPointOnBounds(position);
                direction.x *= direction.x * tmp.x > 0 ? -1 : 1;
                direction.y *= direction.y * tmp.y > 0 ? -1 : 1;
            }
            else
            {
                direction.x *= xColl ? -1 : 1;
                direction.y *= !xColl && yColl ? -1 : 1;
            }

            Destroy(other.gameObject);
        }
        else if (other.tag == "Border")
        {
            direction.y *= other.name == "TopBorder" && direction.y > 0 ? -1 : 1;
            direction.x *= other.name == "LeftBorder" && direction.x < 0 ? -1 : 1;
            direction.x *= other.name == "RightBorder" && direction.x > 0 ? -1 : 1;
        }
    }
}
