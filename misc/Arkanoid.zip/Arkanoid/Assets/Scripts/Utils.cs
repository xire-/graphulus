﻿using UnityEngine;

public class Utils
{
    public static float SaneMod(float a, float b)
    {
        return (a % b + b) % b;
    }

    public static float Clamp(float lower, float x, float upper)
    {
        return Mathf.Max(lower, Mathf.Min(x, upper));
    }
}
